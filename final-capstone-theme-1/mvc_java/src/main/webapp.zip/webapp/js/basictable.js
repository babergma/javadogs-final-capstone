jQuery(function($) {

    $('#dataTable').DataTable( {
    } );
});