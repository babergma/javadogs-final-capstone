var editorEmp;
jQuery(function($) {
    function format(d) {
        return '<table cellpadding="5" cellspacing="0" border="0" style="padding-left:50px;">'+
            '<tr>'+
            '<td>First Name:</td>'+
            '<td>'+d.firstName+'</td>'+
            '</tr>'+
            '<tr>'+
            '<td>Last Name:</td>'+
            '<td>'+d.lastName+'</td>'+
            '</tr>'+
            '<tr>'+
            '<td>Position:</td>'+
            '<td>' + d.position + '</td>'+
            '</tr>'+

            '<tr>'+
            '<td>Office:</td>'+
            '<td>' + d.office + '</td>'+
            '</tr>'+

            '<tr>'+
            '<td>Start Date:</td>'+
            '<td>' + d.startDate + '</td>'+
            '</tr>'+

            '<tr>'+
            '<td>Salary:</td>'+
            '<td>' + d.salary + '</td>'+
            '</tr>'+
            '</table>';
    }

    $(document).ready(function() {
        editorEmp = new $.fn.dataTable.Editor({
            ajax: "/user/rest/employees",
            table: "#employees",
            fields: [{
                label: "First name:",
                name: "firstName"
            }, {
                label: "Last name:",
                name: "lastName"
            }, {
                label: "Position:",
                name: "position"
            }, {
                label: "Office:",
                name: "office"
            }, {
                label: "Start date:",
                name: "startDate",
                type: "datetime"
            }, {
                label: "Salary:",
                name: "salary"
            }
            ]
        });
    });
    var employeeTable = $('#employees').DataTable( {
        processing: true,
        serverSide: false,
        order: [[ 4, "desc" ]],
        ajax: {
            url: "/user/rest/employees",
            type: "GET"
        },
        columns: [
            { data: "firstName" },
            { data: "lastName" },
            { data: "position" },
            { data: "office" },
            { data: "startDate" },
            { data: "salary" }
        ],
        select: true
    } );


    $('#employees tbody').on('click', 'tr', function () {
        var tr = $(this).closest('tr');
        var row = employeeTable.row( this );
        var data = row.data();
        if ( row.child.isShown() ) {
            // This row is already open - close it
            row.child.hide();
            //tr.removeClass('shown');
        }
        else {
            // Open this row
            row.child( format(row.data()) ).show();
            tr.addClass('shown');
        }
    } );


});